Sube estos archivos a tu repo (misma carpeta). Activa GitHub Pages desde main / root.
Abre: https://TUUSUARIO.github.io/TUREPO/
Si no responde, prueba Ctrl+Shift+R o modo incógnito.


v75 UNIVERSAL:
- Sin scripts inline (apto para CSP)
- data-cfasync=false (Cloudflare Rocket Loader)
- Fallback para <dialog> en navegadores sin showModal
- Overlay visible si JS no carga (para diagnosticar)
- .htaccess opcional (mejor mime + no-cache)
